<!-- Main Footer -->
<footer class="main-footer">
  <strong>Copyright &copy; 2025 <a href="http://adminlte.io">PT. TKM</a>.</strong>
  All rights reserved.
  <div class="float-right d-none d-sm-inline-block">
    <b>Version</b> 0.0.1
  </div>
</footer>
</div>
<!-- ./wrapper -->
